package com.sample.recorder;

import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.view.Menu;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import com.sample.recorder.RecorderMainActivity;
import com.sample.recorder.MusicPlayer;

import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.View.OnClickListener;


public class RecorderMainActivity extends Activity implements OnClickListener {
    
    private Button btnStart;
    private Button btnStop;
    private Button btnPlay;

    private MusicPlayer mPlayer;
    private MediaRecorder mMediaRecorder;
    private File recAudioFile;
    private File myRecAudioDir;
    private ListView myListViewRec;
    private TextView myTextViewRec;
    private String strTempFile = "snd_rec_";
    
    private ArrayList<String> recordFiles;
    private ArrayAdapter<String> adapter;
    private boolean sdCardExit;
    private boolean isStopRecord;

    private void setupViews() {
        btnStart = (Button) findViewById(R.id.button_rec);  // �������
        btnStop = (Button) findViewById(R.id.button_stop);
        btnPlay = (Button) findViewById(R.id.button_play);
        myListViewRec = (ListView) findViewById(R.id.ListViewRec);
        myTextViewRec = (TextView) findViewById(R.id.TextViewRec);
        
        btnStart.setOnClickListener(this);
        btnStop.setOnClickListener(this);
        btnPlay.setOnClickListener(this);
        
        sdCardExit = Environment.getExternalStorageState().equals(
                android.os.Environment.MEDIA_MOUNTED);
            if (sdCardExit)
              myRecAudioDir = Environment.getExternalStorageDirectory();


            getRecordFiles();
        
            adapter = new ArrayAdapter<String>(this,
                    R.layout.my_simple_list_item, recordFiles);

              myListViewRec.setAdapter(adapter);
       // recAudioFile = new File("/mnt/sdcard", "rec.amr");   // ���¼���ļ�
        
    }
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recorder_main);
        
        setupViews();   // ��ʼ��view
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_recorder_main, menu);
        return true;
    }

    public void onClick(View v) {
        switch (v.getId()) {
        case R.id.button_rec:
            startRecorder();
            break;
        case R.id.button_stop:
            stopRecorder();
            break;
        case R.id.button_play:
        	mPlayer = new MusicPlayer(RecorderMainActivity.this);
			mPlayer.playMicFile(recAudioFile);
            break;
        default:
            break;
        }
    }
    
    private void startRecorder() {
    	try {
    		
	    	if (!sdCardExit)
	        {
	          Toast.makeText(RecorderMainActivity.this, "Can't find SD Card",
	              Toast.LENGTH_LONG).show();
	          return;
	        }
	
	
	    	recAudioFile = File.createTempFile(strTempFile, ".amr",
	            myRecAudioDir);
	        
	        mMediaRecorder = new MediaRecorder();
	       // if (recAudioFile.exists()) {
	       //     recAudioFile.delete();
	       // }
	
	        mMediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC); 
	        mMediaRecorder.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT);
	        mMediaRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT);
	        mMediaRecorder.setOutputFile(recAudioFile.getAbsolutePath());
	        
	        myTextViewRec.setText("On Recording...");
	        
	        
            mMediaRecorder.prepare();
        } catch (IllegalStateException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        mMediaRecorder.start();
    }
    
    private void stopRecorder(){
    	if (recAudioFile != null)
        {

    		mMediaRecorder.stop();

          adapter.add(recAudioFile.getName());
          mMediaRecorder.release();
          mMediaRecorder = null;
          myTextViewRec.setText("����G" + recAudioFile.getName());

          //myButton2.setEnabled(false);

          isStopRecord = true;
        }
    }
    
    private void getRecordFiles()
    {
      recordFiles = new ArrayList<String>();
      if (sdCardExit)
      {
        File files[] = myRecAudioDir.listFiles();
        if (files != null)
        {

          for (int i = 0; i < files.length; i++)
          {
            if (files[i].getName().indexOf(".") >= 0)
            {

              String fileS = files[i].getName().substring(
                  files[i].getName().indexOf("."));
              if (fileS.toLowerCase().equals(".amr"))
                recordFiles.add(files[i].getName());

            }
          }
        }
      }
    }

    private void openFile(File f)
    {
      Intent intent = new Intent();
      intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      intent.setAction(android.content.Intent.ACTION_VIEW);

      String type = getMIMEType(f);
      intent.setDataAndType(Uri.fromFile(f), type);
      startActivity(intent);
    }
    
    private String getMIMEType(File f)
    {
      String end = f.getName().substring(
          f.getName().lastIndexOf(".") + 1, f.getName().length())
          .toLowerCase();
      String type = "";
      if (end.equals("mp3") || end.equals("aac") || end.equals("aac")
          || end.equals("amr") || end.equals("mpeg")
          || end.equals("mp4"))
      {
        type = "audio";
      } else if (end.equals("jpg") || end.equals("gif")
          || end.equals("png") || end.equals("jpeg"))
      {
        type = "image";
      } else
      {
        type = "*";
      }
      type += "/*";
      return type;
    }
}
